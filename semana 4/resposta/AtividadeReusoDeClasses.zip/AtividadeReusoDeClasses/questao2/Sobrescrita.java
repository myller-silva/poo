public class Sobrescrita {
    public static void main(String[] args) {
        int n1 = 1;
        double n2 = 2.2;
        String nome = "mac";

        ExemplosParaSobrescrita ex = new ExemplosParaSobrescrita();
        ex.exibirParametro(n1);
        
        // isso é sobrescrita: a possibilidade de alterar o funcionamento de um metodo para que ele funcione adequadamente na classe herdeira



    }
    
    
}
