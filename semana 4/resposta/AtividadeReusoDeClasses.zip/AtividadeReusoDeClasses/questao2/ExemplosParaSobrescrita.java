public class ExemplosParaSobrescrita extends Exemplos{
    void exibirParametro(int valor){
        System.out.println("As instrucoes que anteriormente eram feitas ao se oferecer um inteiro como parametro foi auterada devido a sobrescrita");
        
    }
    // void exibirParametro(double valor){
    //     System.out.printf("O parametro '%.2f' eh um valor double\n", valor);
    // }
    // void exibirParametro(String valor){
    //     System.out.printf("O parametro '%s' eh uma string\n", valor);
    // }
    
}
